# StackDialer - Real Native Android Dialer App & APK

StackDialer is a full-fledged native Android dialer replacement application built with Flutter & Android Telecom, designed to run with real SIM carrier calling, native incoming/outgoing call screens, device contacts, call logs, and system default dialer support.

## 📱 Real Android Features Included

1. **Dedicated Incoming Call Screen (Apna Incoming UI)**:
   - Full-screen high-end dark luxury UI with pulsing neon caller avatar.
   - Caller Name, Number, SIM Line (`SIM 1 Jio 5G` / `SIM 2 Airtel`), and Spam Filter Risk indicator.
   - Swipe/Tap to Answer (Emerald Green) & Slide/Tap to Decline (Crimson Red).
   - Quick SMS responses drawer (*"Can't talk right now"*, *"In a meeting"*, etc.).

2. **Dedicated Outgoing & Active Call Screen (Apna Outgoing UI)**:
   - Full-screen HD voice in-call interface with live duration timer (`MM:SS`).
   - Carrier line indicator with 48kHz HD voice encryption tag.
   - **6 In-Call Controls**:
     * 🎙️ **Mute**: Toggles hardware microphone mute via `InCallService`.
     * 🔢 **DTMF Keypad**: Slide-up dialpad overlay for IVR navigation (0-9, *, #) with real DTMF tone feedback.
     * 🔊 **Speakerphone**: Toggles between earpiece and loudspeaker.
     * ⏸️ **Hold**: Real carrier call hold/unhold.
     * ⏺️ **Call Recorder**: Live in-call audio recording toggle with blinking REC indicator.
     * 📝 **In-Call Notes**: Take notes during a call that save directly onto the call record!
     * 🔴 **End Call Button**: Disconnects call with haptic vibration.

3. **Post-Call Summary Modal**:
   - Call duration summary with timestamp.
   - Quick 1-tap WhatsApp chat button.
   - Quick 1-tap SMS message button.
   - Block / Mark as Spam button.
   - Add note / reminder to the recents card.

4. **3D Kinetic Card Stack Recents (All 10 Styles)**:
   - iOS Depth Stack (iOS 18 shade rollup).
   - 3D Coverflow Deck (macOS coverflow tilt).
   - Cascade Waterfall (diagonal drift).
   - Cyberpunk Neon (isometric tilt + neon glow).
   - Origami 3D Fold (accordion fold).
   - Helix Spiral (vortex depth).
   - Carousel Reel (cylinder carousel).
   - Hologram HUD (floating glass).
   - Tinder Swipe Deck (tangent rotation swipe).
   - Executive Minimal (ultra clean).

5. **T9 Smart Dialpad & Speed Dial**:
   - Long press on Key 1: Voicemail (*123#).
   - Long press on Keys 2–9: Instantly calls assigned favorite contact!
   - Dual SIM toggle pill (SIM 1 Jio 5G / SIM 2 Airtel).
   - Real-time contact matching with avatar preview.

6. **Spam & Blocked Numbers Protection**:
   - Built-in spam detection and blacklist manager.
   - Unblock / block numbers directly from call details.

7. **Default Phone App System Integration**:
   - Android `InCallService` and `RoleManager` integration.
   - Responds to `android.intent.action.DIAL`, `ACTION_CALL_BUTTON`, and `tel:` URIs.

---

## 🚀 How to Build & Download the Android APK

### Option A: 1-Click Free GitHub Cloud Build (Zero local tools needed)
1. Push this repository to your GitHub account (or fork it).
2. Open the **Actions** tab on your GitHub repository.
3. Select **"Build StackDialer Android APK"** from the left sidebar.
4. Click **Run workflow** -> **Run workflow**.
5. GitHub will compile the APK in ~2-3 minutes.
6. Under the completed workflow run, download **`StackDialer-Release-APK`**!
7. Transfer to your phone and install!

### Option B: Local Command Line (If you have Flutter installed)
1. Open terminal and navigate to `flutter_app/`:
   ```bash
   cd flutter_app
   ```
2. Install packages:
   ```bash
   flutter pub get
   ```
3. Build the release APK:
   ```bash
   flutter build apk --release
   ```
4. Your APK will be ready at:
   `build/app/outputs/flutter-apk/app-release.apk`
