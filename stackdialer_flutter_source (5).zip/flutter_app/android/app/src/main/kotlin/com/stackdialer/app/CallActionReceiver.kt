package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_ANSWER = "com.stackdialer.app.ACTION_ANSWER"
        const val ACTION_REJECT = "com.stackdialer.app.ACTION_REJECT"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val number = intent.getStringExtra("number") ?: "Unknown"

        if (action == ACTION_ANSWER) {
            InCallServiceImpl.answerCurrentCall()
            MainActivity.cancelIncomingCallBanner(context)
            MainActivity.notifyCallState(number, "ACTIVE")

            // Bring MainActivity to the front
            val appIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra("answered_number", number)
            }
            if (appIntent != null) {
                context.startActivity(appIntent)
            }
        } else if (action == ACTION_REJECT) {
            InCallServiceImpl.rejectCurrentCall()
            MainActivity.cancelIncomingCallBanner(context)
            MainActivity.notifyCallState(number, "DISCONNECTED")
        }
    }
}
