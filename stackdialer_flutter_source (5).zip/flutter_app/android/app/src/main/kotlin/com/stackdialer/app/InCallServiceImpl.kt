package com.stackdialer.app

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

class InCallServiceImpl : InCallService() {

    companion object {
        var instance: InCallServiceImpl? = null
        var currentCall: Call? = null
        var onCallStateChangedListener: ((String, String, Int) -> Unit)? = null

        fun answerCurrentCall() {
            currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }

        fun rejectCurrentCall() {
            currentCall?.reject(false, null)
        }

        fun disconnectCurrentCall() {
            currentCall?.disconnect()
        }

        fun holdCurrentCall(hold: Boolean) {
            if (hold) {
                currentCall?.hold()
            } else {
                currentCall?.unhold()
            }
        }

        fun setSpeaker(enabled: Boolean) {
            instance?.setAudioRoute(if (enabled) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
        }

        fun setMuted(muted: Boolean) {
            instance?.setMuted(muted)
        }

        fun playDtmf(digit: Char) {
            currentCall?.playDtmfTone(digit)
        }

        fun stopDtmf() {
            currentCall?.stopDtmfTone()
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        instance = this
        currentCall = call

        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val state = call.state

        if (state == Call.STATE_RINGING) {
            MainActivity.showIncomingCallBanner(this, number, null)
        }

        notifyState(number, state)

        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                super.onStateChanged(call, state)
                val num = call.details?.handle?.schemeSpecificPart ?: "Unknown"
                if (state == Call.STATE_RINGING) {
                    MainActivity.showIncomingCallBanner(this@InCallServiceImpl, num, null)
                } else if (state == Call.STATE_ACTIVE || state == Call.STATE_DISCONNECTED) {
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                }
                notifyState(num, state)
            }
        })
    }

    private fun notifyState(number: String, state: Int) {
        Handler(Looper.getMainLooper()).post {
            onCallStateChangedListener?.invoke(number, getStateString(state), state)
        }
    }

    private fun getStateString(state: Int): String {
        return when (state) {
            Call.STATE_RINGING -> "RINGING"
            Call.STATE_DIALING -> "DIALING"
            Call.STATE_ACTIVE -> "ACTIVE"
            Call.STATE_HOLDING -> "HOLDING"
            Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> "UNKNOWN"
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (currentCall == call) {
            currentCall = null
        }
        MainActivity.cancelIncomingCallBanner(this)
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        notifyState(number, Call.STATE_DISCONNECTED)
    }
}
