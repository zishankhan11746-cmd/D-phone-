package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class PhoneCallReceiver : BroadcastReceiver() {
    companion object {
        private var lastState = TelephonyManager.EXTRA_STATE_IDLE
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Unknown"

            if (stateStr == lastState) return
            lastState = stateStr

            when (stateStr) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    // Show incoming call notification banner
                    MainActivity.showIncomingCallBanner(context, incomingNumber, null)
                    MainActivity.notifyCallState(incomingNumber, "RINGING")
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    MainActivity.cancelIncomingCallBanner(context)
                    MainActivity.notifyCallState(incomingNumber, "ACTIVE")
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    MainActivity.cancelIncomingCallBanner(context)
                    MainActivity.notifyCallState(incomingNumber, "DISCONNECTED")
                }
            }
        }
    }
}
