package com.stackdialer.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.provider.CallLog
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.stackdialer.app/telecom"
    private val REQUEST_ID_SET_DEFAULT_DIALER = 1001

    companion object {
        const val CHANNEL_ID = "stackdialer_incoming_calls"
        const val NOTIFICATION_ID = 2001
        var methodChannel: MethodChannel? = null

        fun notifyCallState(number: String, state: String) {
            methodChannel?.invokeMethod("onCallStateChanged", mapOf(
                "number" to number,
                "state" to state
            ))
        }

        fun showIncomingCallBanner(context: Context, number: String, name: String?) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Create high-priority notification channel with ringtone & vibration
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build()

                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "StackDialer Incoming Calls",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alerts for incoming phone calls"
                    enableLights(true)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 1000, 500, 1000)
                    setSound(soundUri, audioAttributes)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }

            // Full screen intent to bring StackDialer to front
            val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("incoming_number", number)
                putExtra("incoming_name", name ?: number)
            }
            val fullScreenPendingIntent = PendingIntent.getActivity(
                context,
                0,
                fullScreenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Answer Action PendingIntent
            val answerIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_ANSWER
                putExtra("number", number)
            }
            val answerPendingIntent = PendingIntent.getBroadcast(
                context,
                1,
                answerIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Reject Action PendingIntent
            val rejectIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_REJECT
                putExtra("number", number)
            }
            val rejectPendingIntent = PendingIntent.getBroadcast(
                context,
                2,
                rejectIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val displayName = if (!name.isNullOrBlank()) name else number
            val contentText = if (!name.isNullOrBlank()) "Incoming call • $number" else "Incoming Call..."

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(displayName)
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(true)
                .setOngoing(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(fullScreenPendingIntent, true)
                .setContentIntent(fullScreenPendingIntent)
                .addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)

            notificationManager.notify(NOTIFICATION_ID, builder.build())
        }

        fun cancelIncomingCallBanner(context: Context) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(NOTIFICATION_ID)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getCallLogs" -> {
                    try {
                        val logs = fetchNativeCallLogs()
                        result.success(logs)
                    } catch (e: Exception) {
                        result.error("CALL_LOG_ERROR", e.message, null)
                    }
                }
                "requestDefaultDialer" -> {
                    requestSetDefaultDialer()
                    result.success(true)
                }
                "isDefaultDialer" -> {
                    val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    val isDefault = telecomManager.defaultDialerPackage == packageName
                    result.success(isDefault)
                }
                "answerCall" -> {
                    InCallServiceImpl.answerCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "rejectCall" -> {
                    InCallServiceImpl.rejectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "disconnectCall" -> {
                    InCallServiceImpl.disconnectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "holdCall" -> {
                    val hold = call.argument<Boolean>("hold") ?: false
                    InCallServiceImpl.holdCurrentCall(hold)
                    result.success(true)
                }
                "setSpeaker" -> {
                    val enabled = call.argument<Boolean>("enabled") ?: false
                    InCallServiceImpl.setSpeaker(enabled)
                    result.success(true)
                }
                "setMuted" -> {
                    val muted = call.argument<Boolean>("muted") ?: false
                    InCallServiceImpl.setMuted(muted)
                    result.success(true)
                }
                "playDtmf" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull() ?: '1'
                    InCallServiceImpl.playDtmf(digit)
                    result.success(true)
                }
                "stopDtmf" -> {
                    InCallServiceImpl.stopDtmf()
                    result.success(true)
                }
                "showIncomingBanner" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    showIncomingCallBanner(this, number, name)
                    result.success(true)
                }
                "cancelIncomingBanner" -> {
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        // Listen for call state updates from InCallService
        InCallServiceImpl.onCallStateChangedListener = { number, stateStr, _ ->
            if (stateStr == "RINGING") {
                showIncomingCallBanner(this, number, null)
            } else if (stateStr == "DISCONNECTED") {
                cancelIncomingCallBanner(this)
            }
            notifyCallState(number, stateStr)
        }
    }

    private fun fetchNativeCallLogs(): List<Map<String, Any>> {
        val list = mutableListOf<Map<String, Any>>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.GEOCODED_LOCATION
        )

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC LIMIT 100"
        )

        cursor?.use {
            val idIdx = it.getColumnIndex(CallLog.Calls._ID)
            val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
            val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)
            val durIdx = it.getColumnIndex(CallLog.Calls.DURATION)
            val locIdx = it.getColumnIndex(CallLog.Calls.GEOCODED_LOCATION)

            while (it.moveToNext()) {
                val id = if (idIdx >= 0) it.getString(idIdx) ?: "" else ""
                val number = if (numIdx >= 0) it.getString(numIdx) ?: "Unknown" else "Unknown"
                val name = if (nameIdx >= 0) it.getString(nameIdx) ?: "" else ""
                val type = if (typeIdx >= 0) it.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                val date = if (dateIdx >= 0) it.getLong(dateIdx) else System.currentTimeMillis()
                val duration = if (durIdx >= 0) it.getLong(durIdx) else 0L
                val loc = if (locIdx >= 0) it.getString(locIdx) ?: "" else ""

                val typeStr = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    CallLog.Calls.MISSED_TYPE -> "missed"
                    CallLog.Calls.REJECTED_TYPE -> "rejected"
                    CallLog.Calls.VOICEMAIL_TYPE -> "missed"
                    CallLog.Calls.BLOCKED_TYPE -> "blocked"
                    else -> "incoming"
                }

                list.add(mapOf(
                    "id" to id,
                    "number" to number,
                    "name" to name,
                    "type" to typeStr,
                    "timestamp" to date,
                    "duration" to duration,
                    "location" to loc
                ))
            }
        }
        return list
    }

    private fun requestSetDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
            }
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            }
            startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
        }
    }
}
