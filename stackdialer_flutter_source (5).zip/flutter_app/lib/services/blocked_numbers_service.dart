class BlockedNumbersService {
  static final Set<String> _blockedNumbers = {
    '+91 14000 00000',
    '+91 99999 00000',
    '1409210000',
  };

  static List<String> get blockedList => _blockedNumbers.toList();

  static bool isBlocked(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    return _blockedNumbers.any((b) =>
        b.replaceAll(RegExp(r'[^\d+]'), '') == clean ||
        clean.contains('140') ||
        (clean.length > 7 && clean.endsWith('00000')));
  }

  static void blockNumber(String number) {
    if (number.trim().isNotEmpty) {
      _blockedNumbers.add(number.trim());
    }
  }

  static void unblockNumber(String number) {
    _blockedNumbers.remove(number.trim());
  }
}
