import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import '../models/call_record.dart';
import '../models/contact.dart';

typedef CallStateCallback = void Function(String number, String state);

class TelecomService {
  static const MethodChannel _channel = MethodChannel('com.stackdialer.app/telecom');
  static CallStateCallback? _listener;

  static void setupCallListener(CallStateCallback callback) {
    _listener = callback;
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'onCallStateChanged') {
        final args = call.arguments as Map<dynamic, dynamic>?;
        final number = (args?['number'] as String?) ?? '';
        final state = (args?['state'] as String?) ?? 'IDLE';
        _listener?.call(number, state);
      }
    });
  }

  static Future<bool> requestPermissions() async {
    try {
      final statuses = await [
        Permission.phone,
        Permission.contacts,
        Permission.notification,
      ].request();
      return statuses.values.every((s) => s.isGranted);
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isDefaultDialer() async {
    try {
      final bool? isDefault = await _channel.invokeMethod('isDefaultDialer');
      return isDefault ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestDefaultDialer() async {
    try {
      await _channel.invokeMethod('requestDefaultDialer');
    } catch (_) {}
  }

  static Future<bool> makeRealCall(String phoneNumber) async {
    final clean = phoneNumber.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return false;

    try {
      final bool? res = await FlutterPhoneDirectCaller.callNumber(clean);
      if (res == true) return true;
    } catch (_) {}

    final Uri uri = Uri(scheme: 'tel', path: clean);
    if (await canLaunchUrl(uri)) {
      return await launchUrl(uri);
    }
    return false;
  }

  static Future<void> answerCall() async {
    try {
      await _channel.invokeMethod('answerCall');
    } catch (_) {}
  }

  static Future<void> rejectCall() async {
    try {
      await _channel.invokeMethod('rejectCall');
    } catch (_) {}
  }

  static Future<void> disconnectCall() async {
    try {
      await _channel.invokeMethod('disconnectCall');
    } catch (_) {}
  }

  static Future<void> setMuted(bool isMuted) async {
    try {
      await _channel.invokeMethod('setMuted', {'muted': isMuted});
    } catch (_) {}
  }

  static Future<void> setSpeaker(bool isSpeaker) async {
    try {
      await _channel.invokeMethod('setSpeaker', {'speaker': isSpeaker});
    } catch (_) {}
  }

  static Future<void> holdCall(bool isHold) async {
    try {
      await _channel.invokeMethod('holdCall', {'hold': isHold});
    } catch (_) {}
  }

  static void playDtmf(String digit) {
    try {
      _channel.invokeMethod('playDtmf', {'digit': digit});
    } catch (_) {}
  }

  static void stopDtmf() {
    try {
      _channel.invokeMethod('stopDtmf');
    } catch (_) {}
  }

  static Future<void> showIncomingBanner(String number, [String? name]) async {
    try {
      await _channel.invokeMethod('showIncomingBanner', {
        'number': number,
        'name': name,
      });
    } catch (_) {}
  }

  static Future<void> cancelIncomingBanner() async {
    try {
      await _channel.invokeMethod('cancelIncomingBanner');
    } catch (_) {}
  }

  static Future<List<CallRecord>> fetchDeviceCallLogs() async {
    try {
      final dynamic rawLogs = await _channel.invokeMethod('getCallLogs');
      if (rawLogs is List && rawLogs.isNotEmpty) {
        final List<CallRecord> records = [];
        for (final raw in rawLogs) {
          if (raw is Map) {
            final id = raw['id']?.toString() ?? 'log_${DateTime.now().microsecondsSinceEpoch}';
            final number = raw['number']?.toString() ?? 'Unknown';
            final rawName = raw['name']?.toString() ?? '';
            final typeStr = raw['type']?.toString() ?? 'incoming';
            final timestampMs = raw['timestamp'] is num ? (raw['timestamp'] as num).toInt() : DateTime.now().millisecondsSinceEpoch;
            final durationSec = raw['duration'] is num ? (raw['duration'] as num).toInt() : 0;
            final loc = raw['location']?.toString() ?? 'Mobile';

            CallType type = CallType.incoming;
            if (typeStr == 'outgoing') {
              type = CallType.outgoing;
            } else if (typeStr == 'missed') {
              type = CallType.missed;
            } else if (typeStr == 'rejected') {
              type = CallType.rejected;
            }

            records.add(
              CallRecord(
                id: id,
                name: rawName.isNotEmpty ? rawName : number,
                number: number,
                type: type,
                timestamp: DateTime.fromMillisecondsSinceEpoch(timestampMs),
                durationSeconds: durationSec,
                simSlot: 1,
                simCarrier: 'Carrier SIM',
                category: rawName.isNotEmpty ? 'Contact' : 'Recent',
                location: loc.isNotEmpty ? loc : 'Mobile',
              ),
            );
          }
        }
        if (records.isNotEmpty) {
          return records;
        }
      }
    } catch (e) {
      // fallback to sample if native call log query is unavailable or permission denied
    }

    // Default pristine sample logs if no device logs available
    final now = DateTime.now();
    return [
      CallRecord(
        id: 'sample-1',
        name: 'Alihosen Mondal',
        number: '+91 98201 45892',
        type: CallType.missed,
        timestamp: now.subtract(const Duration(minutes: 15)),
        durationSeconds: 0,
        simSlot: 1,
        simCarrier: 'Jio 5G',
        category: 'Personal',
        location: 'Mobile',
        note: 'Birthday celebration tonight at 8 PM',
      ),
      CallRecord(
        id: 'sample-2',
        name: 'Sanib Ansari',
        number: '+91 97654 21980',
        type: CallType.incoming,
        timestamp: now.subtract(const Duration(hours: 1)),
        durationSeconds: 142,
        simSlot: 1,
        simCarrier: 'Jio 5G',
        category: 'Office',
        location: 'Work',
      ),
      CallRecord(
        id: 'sample-3',
        name: 'Papa Office',
        number: '+91 98330 11244',
        type: CallType.outgoing,
        timestamp: now.subtract(const Duration(hours: 3)),
        durationSeconds: 318,
        simSlot: 2,
        simCarrier: 'Airtel 5G',
        category: 'Family',
        location: 'Home',
      ),
      CallRecord(
        id: 'sample-4',
        name: 'Kolkata Zonal Hub',
        number: '+91 33 2289 9000',
        type: CallType.incoming,
        timestamp: now.subtract(const Duration(hours: 5)),
        durationSeconds: 45,
        simSlot: 1,
        simCarrier: 'Jio 5G',
        category: 'Support',
        location: 'Headquarters',
      ),
      CallRecord(
        id: 'sample-5',
        name: 'Amazon Delivery Agent',
        number: '+91 80001 92834',
        type: CallType.incoming,
        timestamp: now.subtract(const Duration(days: 1)),
        durationSeconds: 64,
        simSlot: 2,
        simCarrier: 'Airtel 5G',
        category: 'Services',
        location: 'Logistics',
      ),
      CallRecord(
        id: 'sample-6',
        name: 'Dr. R. K. Sharma',
        number: '+91 98110 33451',
        type: CallType.outgoing,
        timestamp: now.subtract(const Duration(days: 1, hours: 4)),
        durationSeconds: 520,
        simSlot: 1,
        simCarrier: 'Jio 5G',
        category: 'Medical',
        location: 'Clinic',
      ),
    ];
  }

  static Future<List<ContactModel>> fetchDeviceContacts() async {
    try {
      final bool hasPermission = await FlutterContacts.requestPermission(readonly: true);
      if (hasPermission) {
        final List<Contact> contacts = await FlutterContacts.getContacts(
          withProperties: true,
          withPhoto: false,
        );
        if (contacts.isNotEmpty) {
          return contacts.where((c) => c.phones.isNotEmpty).map((c) {
            final phone = c.phones.first.number;
            return ContactModel(
              id: c.id,
              name: c.displayName,
              number: phone,
              company: 'Device Contact',
              isFavorite: false,
            );
          }).toList();
        }
      }
    } catch (_) {}

    return [
      ContactModel(id: 'c1', name: 'Alihosen Mondal', number: '+91 98201 45892', company: 'Personal', isFavorite: true),
      ContactModel(id: 'c2', name: 'Sanib Ansari', number: '+91 97654 21980', company: 'Office', isFavorite: true),
      ContactModel(id: 'c3', name: 'Papa Office', number: '+91 98330 11244', company: 'Family', isFavorite: true),
      ContactModel(id: 'c4', name: 'Kolkata Zonal Hub', number: '+91 33 2289 9000', company: 'Support', isFavorite: false),
      ContactModel(id: 'c5', name: 'Amazon Delivery Agent', number: '+91 80001 92834', company: 'Services', isFavorite: false),
      ContactModel(id: 'c6', name: 'Dr. R. K. Sharma', number: '+91 98110 33451', company: 'Medical', isFavorite: false),
    ];
  }
}
