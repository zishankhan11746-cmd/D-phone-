import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'services/telecom_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StackDialer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF141219),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(
          ThemeData(brightness: Brightness.dark).textTheme,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          surface: Color(0xFF1E1C25),
        ),
      ),
      home: const MainDialerHost(),
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> with WidgetsBindingObserver {
  int _currentIndex = 0;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;
  bool _isDefaultDialer = false;
  String? _incomingBannerNumber;
  String? _incomingBannerName;
  final List<CallRecord> _recentDialedCalls = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initDeviceData();
    _checkDefaultDialer();
    _setupTelecomInCallListener();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Whenever user returns from making a phone call or switching back,
      // reload live device call logs and update default dialer status!
      _checkDefaultDialer();
      _refreshCallLogs();
    }
  }

  Future<void> _checkDefaultDialer() async {
    try {
      final isDef = await TelecomService.isDefaultDialer();
      if (mounted) {
        setState(() => _isDefaultDialer = isDef);
      }
    } catch (_) {}
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      if (state == 'RINGING') {
        // Show floating heads-up banner & open active call screen
        final matched = _findContact(number);
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
        });
        _openIncomingCallScreen(number, matched?.name);
      } else if (state == 'DISCONNECTED' || state == 'IDLE') {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
        });
        // Call ended, refresh live device call log!
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) _refreshCallLogs();
        });
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _callLogs = _mergeCalls(logs, _recentDialedCalls);
        _contacts = contacts;
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshCallLogs() async {
    try {
      final logs = await TelecomService.fetchDeviceCallLogs();
      if (mounted) {
        setState(() {
          _callLogs = _mergeCalls(logs, _recentDialedCalls);
        });
      }
    } catch (_) {}
  }

  List<CallRecord> _mergeCalls(List<CallRecord> deviceLogs, List<CallRecord> localCalls) {
    final Map<String, CallRecord> map = {};
    // Add local calls first
    for (final c in localCalls) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    // Add or override with real device logs
    for (final c in deviceLogs) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    final merged = map.values.toList();
    merged.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return merged;
  }

  ContactModel? _findContact(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d]'), '');
    if (clean.isEmpty) return null;
    return _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(clean),
          orElse: () => null,
        );
  }

  void _openIncomingCallScreen(String number, [String? name]) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;

    final matched = _findContact(number);
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: name ?? matched?.name,
          callerCategory: 'Incoming Call',
          isIncoming: true,
          simSlot: 1,
          onCallEnded: (record) {
            _handleCompletedCall(record);
          },
        ),
        transitionsBuilder: (context, anim, secAnim, child) {
          return FadeTransition(opacity: anim, child: child);
        },
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
      if (mounted) {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
        });
        _refreshCallLogs();
      }
    });
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    HapticFeedback.heavyImpact();
    final clean = number.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return;

    final matched = _findContact(clean);

    // 1. Immediately create a real CallRecord and insert it at the TOP of recent calls!
    final newOutgoingRecord = CallRecord(
      id: 'call_${DateTime.now().millisecondsSinceEpoch}',
      name: matched?.name ?? clean,
      number: clean,
      type: CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: 0,
      simSlot: simSlot,
      simCarrier: simSlot == 1 ? 'Jio 5G' : 'Airtel 5G',
      category: matched?.company ?? 'Personal',
      location: 'Mobile Outgoing',
    );

    setState(() {
      _recentDialedCalls.insert(0, newOutgoingRecord);
      _callLogs.insert(0, newOutgoingRecord);
    });

    // 2. Launch real native SIM call via Android Carrier
    await TelecomService.makeRealCall(clean);

    // 3. Immediately present the executive Outgoing ActiveCallScreen
    if (!_hasActiveCallScreen) {
      _hasActiveCallScreen = true;
      if (mounted) {
        Navigator.of(context).push(
          PageRouteBuilder(
            opaque: true,
            transitionDuration: const Duration(milliseconds: 300),
            pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
              phoneNumber: clean,
              contactName: matched?.name,
              callerCategory: matched?.company ?? 'Mobile',
              simSlot: simSlot,
              isIncoming: false,
              onCallEnded: (record) {
                _handleCompletedCall(record);
              },
            ),
            transitionsBuilder: (context, anim, secAnim, child) {
              return SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 1),
                  end: Offset.zero,
                ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
                child: child,
              );
            },
          ),
        ).then((_) {
          _hasActiveCallScreen = false;
          if (mounted) {
            _refreshCallLogs();
          }
        });
      }
    }
  }

  void _handleCompletedCall(CallRecord record) {
    setState(() {
      _recentDialedCalls.removeWhere((c) => c.number == record.number && DateTime.now().difference(c.timestamp).inSeconds < 180);
      _recentDialedCalls.insert(0, record);
      _callLogs.removeWhere((c) => c.number == record.number && DateTime.now().difference(c.timestamp).inSeconds < 180);
      _callLogs.insert(0, record);
    });
  }

  void _onSimulateIncomingCall() {
    setState(() {
      _incomingBannerNumber = '+91 98201 45892';
      _incomingBannerName = 'Alihosen Mondal';
    });
    TelecomService.showIncomingBanner('+91 98201 45892', 'Alihosen Mondal');
    _openIncomingCallScreen('+91 98201 45892', 'Alihosen Mondal');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141219),
      body: Stack(
        children: [
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF10B981)),
                  ),
                )
              : Column(
                  children: [
                    // Optional Default Dialer request header banner
                    if (!_isDefaultDialer)
                      SafeArea(
                        bottom: false,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF38BDF8).withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.verified_user_outlined, color: Color(0xFF38BDF8), size: 18),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Set as Default Phone App to enable incoming call banners & live in-call controls',
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                              ),
                              const SizedBox(width: 8),
                              InkWell(
                                onTap: () async {
                                  await TelecomService.requestDefaultDialer();
                                  await Future.delayed(const Duration(seconds: 1));
                                  _checkDefaultDialer();
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Set Default',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Expanded(
                      child: IndexedStack(
                        index: _currentIndex,
                        children: [
                          StackedRecentsScreen(
                            calls: _callLogs,
                            onRefresh: _refreshCallLogs,
                            onCallNumber: _onCallNumber,
                            onSimulateIncoming: _onSimulateIncomingCall,
                          ),
                          T9DialpadScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                            onSimulateIncoming: _onSimulateIncomingCall,
                          ),
                          ContactsScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                          ),
                          InsightsScreen(
                            calls: _callLogs,
                            onCallNumber: _onCallNumber,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

          // Floating Incoming Call Heads-Up Banner at the top of the app
          if (_incomingBannerNumber != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 24,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF1F1D2B),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF10B981).withOpacity(0.35),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.call_received, color: Color(0xFF10B981), size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _incomingBannerName ?? _incomingBannerNumber!,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              'Incoming Call... • ${_incomingBannerNumber!}',
                              style: const TextStyle(
                                color: Color(0xFF10B981),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Reject Button
                      IconButton(
                        onPressed: () async {
                          await TelecomService.rejectCall();
                          await TelecomService.cancelIncomingBanner();
                          setState(() {
                            _incomingBannerNumber = null;
                            _incomingBannerName = null;
                          });
                        },
                        icon: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                            color: Color(0xFFEF4444),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call_end, color: Colors.white, size: 18),
                        ),
                      ),
                      // Answer Button
                      IconButton(
                        onPressed: () async {
                          await TelecomService.answerCall();
                          await TelecomService.cancelIncomingBanner();
                          final num = _incomingBannerNumber!;
                          setState(() {
                            _incomingBannerNumber = null;
                            _incomingBannerName = null;
                          });
                          _openIncomingCallScreen(num);
                        },
                        icon: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                            color: Color(0xFF10B981),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call, color: Colors.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF121017).withOpacity(0.96),
            border: const Border(
              top: BorderSide(color: Colors.white10, width: 0.5),
            ),
          ),
          child: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (i) {
              HapticFeedback.selectionClick();
              setState(() => _currentIndex = i);
            },
            backgroundColor: Colors.transparent,
            elevation: 0,
            type: BottomNavigationBarType.fixed,
            selectedItemColor: const Color(0xFF10B981),
            unselectedItemColor: Colors.white38,
            selectedFontSize: 11,
            unselectedFontSize: 11,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.layers_outlined),
                activeIcon: Icon(Icons.layers),
                label: 'Recents',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.dialpad_outlined),
                activeIcon: Icon(Icons.dialpad),
                label: 'Keypad',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.contacts_outlined),
                activeIcon: Icon(Icons.contacts),
                label: 'Contacts',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.analytics_outlined),
                activeIcon: Icon(Icons.analytics),
                label: 'Insights',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
